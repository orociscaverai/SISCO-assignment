/*
 * JOrrery.java
 * Created on 18 April 2001, 20:39
 */

package org.johndavidtaylor.jws;
import java.awt.Dimension;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

import org.johndavidtaylor.beans.beanpeeler.BeanPeeler;
import org.johndavidtaylor.jorrery.God;
import org.johndavidtaylor.jorrery.Scenario;
import org.johndavidtaylor.jorrery.utils.FrameCenterer;
import org.johndavidtaylor.jorrery.views.GraphicalViewPanel;
/** This class provides an applet interface to the JOrrery
 * n-body simulator.
 * This code, and all of the code in the com.johndavid_taylor packages
 * and subpackages is released under the terms of the
 * GNU General Public License http://www.gnu.org/copyleft/gpl.html
 * @author JohnDavid_Taylor@hotmail.com
 * @version 1.0
 */
public class JOrrery extends javax.swing.JFrame {

    /**
     * Main point of entry, but you knew that already.
     * @param args
     */
    public static void main(String[] args) {
        JOrrery orrery = new JOrrery();
        orrery.setVisible(true);
        orrery.god.unsuspend();
    }
    /** Creates new form JOrrery */
    public JOrrery() {
      god = new God();
      god.setScenario(god.getInitialScenario()); //there must be at least one
      god.unsuspend();
      //new SolarSystem(false, false));
      GraphicalViewPanel primaryView = god.getPrimaryView();
      initComponents ();
      initMyComponents();
      centrePanel.add(primaryView, java.awt.BorderLayout.CENTER);
      pack();
      new FrameCenterer(this).center();
      setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    private void initComponents() {//GEN-BEGIN:initComponents
        jMenuBar1 = new javax.swing.JMenuBar();
        settingsMenu = new javax.swing.JMenu();
        clockPrefsMenuItem = new javax.swing.JMenuItem();
        planetPrefsMenuItem = new javax.swing.JMenuItem();
        algPrefsMenu = new javax.swing.JMenuItem();
        universePrefsMenu = new javax.swing.JMenuItem();
        fileLocationMenuItem = new javax.swing.JMenuItem();
        jMenu3 = new javax.swing.JMenu();
        jMenuItem7 = new javax.swing.JMenuItem();
        mainPanel = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jPanel4 = new javax.swing.JPanel();
        jButton3 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();
        newTrailsViewButton = new javax.swing.JButton();
        jPanel5 = new javax.swing.JPanel();
        jButton4 = new javax.swing.JButton();
        centrePanel = new javax.swing.JPanel();
        timestepSlider = new javax.swing.JSlider();
        
        settingsMenu.setText("Settings");
        clockPrefsMenuItem.setToolTipText("Changes the clock settings which drives the algorithm");
        clockPrefsMenuItem.setText("Clock");
        clockPrefsMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                clockPrefsMenuItemActionPerformed(evt);
            }
        });
        
        settingsMenu.add(clockPrefsMenuItem);
        planetPrefsMenuItem.setToolTipText("Set the default planet creation properties");
        planetPrefsMenuItem.setText("Planet Creation");
        planetPrefsMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                planetPrefsMenuItemActionPerformed(evt);
            }
        });
        
        settingsMenu.add(planetPrefsMenuItem);
        algPrefsMenu.setToolTipText("Set the algorithm properties");
        algPrefsMenu.setText("Algorithm");
        algPrefsMenu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                algPrefsMenuActionPerformed(evt);
            }
        });
        
        settingsMenu.add(algPrefsMenu);
        universePrefsMenu.setText("Universe");
        universePrefsMenu.setEnabled(false);
        universePrefsMenu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                universePrefsMenuActionPerformed(evt);
            }
        });
        
        settingsMenu.add(universePrefsMenu);
        fileLocationMenuItem.setToolTipText("Specify where you want your scenario xml files stored");
        fileLocationMenuItem.setText("File Locations");
        fileLocationMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                fileLocationMenuItemActionPerformed(evt);
            }
        });
        
        settingsMenu.add(fileLocationMenuItem);
        jMenuBar1.add(settingsMenu);
        jMenu3.setText("Help");
        jMenuItem7.setText("About");
        jMenuItem7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem7ActionPerformed(evt);
            }
        });
        
        jMenu3.add(jMenuItem7);
        jMenuBar1.add(jMenu3);
        
        getContentPane().setLayout(new java.awt.FlowLayout());
        
        setForeground(java.awt.Color.white);
        setBackground(java.awt.Color.black);
        setName("");
        mainPanel.setLayout(new java.awt.BorderLayout());
        
        jLabel1.setText("<html><font color=\"#FF0000\">J</font>Orrery</html>");
        jLabel1.setBackground(java.awt.Color.black);
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setFont(new java.awt.Font("Book Antiqua", 1, 14));
        mainPanel.add(jLabel1, java.awt.BorderLayout.NORTH);
        
        jPanel2.setLayout(new java.awt.GridLayout(1, 2));
        
        jPanel2.setBorder(new javax.swing.border.BevelBorder(javax.swing.border.BevelBorder.RAISED));
        jPanel4.setLayout(new java.awt.GridLayout(4, 0));
        
        jPanel4.setBorder(new javax.swing.border.TitledBorder("View Creation"));
        jButton3.setFont(new java.awt.Font("Dialog", 0, 10));
        jButton3.setText("New Text View");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                newTextViewButton(evt);
            }
        });
        
        jPanel4.add(jButton3);
        
        jButton2.setFont(new java.awt.Font("Dialog", 0, 10));
        jButton2.setText("New Graphical View");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                newGraphicalViewButton(evt);
            }
        });
        
        jPanel4.add(jButton2);
        
        jButton1.setFont(new java.awt.Font("Dialog", 0, 10));
        jButton1.setText("New Time View");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        
        jPanel4.add(jButton1);
        
        newTrailsViewButton.setToolTipText("Create a new view which shows the tracks of the planets");
        newTrailsViewButton.setFont(new java.awt.Font("Dialog", 0, 10));
        newTrailsViewButton.setText("New Trails View");
        newTrailsViewButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                newTrailsViewButtonActionPerformed(evt);
            }
        });
        
        jPanel4.add(newTrailsViewButton);
        
        jPanel2.add(jPanel4);
        
        jPanel5.setBorder(new javax.swing.border.TitledBorder("Planet Creation"));
        jButton4.setFont(new java.awt.Font("Dialog", 0, 10));
        jButton4.setText("New Planet");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                newPlanetButton(evt);
            }
        });
        
        jPanel5.add(jButton4);
        
        jPanel2.add(jPanel5);
        
        mainPanel.add(jPanel2, java.awt.BorderLayout.EAST);
        
        centrePanel.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 0, 0));
        
        centrePanel.setBorder(new javax.swing.border.BevelBorder(javax.swing.border.BevelBorder.LOWERED));
        centrePanel.setBackground(java.awt.Color.lightGray);
        mainPanel.add(centrePanel, java.awt.BorderLayout.CENTER);
        
        timestepSlider.setOrientation(javax.swing.JSlider.VERTICAL);
        timestepSlider.setToolTipText("Change timestep");
        timestepSlider.setBorder(new javax.swing.border.BevelBorder(javax.swing.border.BevelBorder.RAISED));
        timestepSlider.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                timestepSliderStateChanged(evt);
            }
        });
        
        mainPanel.add(timestepSlider, java.awt.BorderLayout.WEST);
        
        getContentPane().add(mainPanel);
        
        setJMenuBar(jMenuBar1);
    }//GEN-END:initComponents

    private void initMyComponents() {
        javax.swing.JMenu scenariosMenu2 = new javax.swing.JMenu();

        Map scenarios = god.getAvailableScenarios();

        Set names = scenarios.keySet();
        Iterator it = names.iterator();
        while (it.hasNext()) {
            String name = (String) it.next();
            javax.swing.JMenuItem item = new javax.swing.JMenuItem(name);
            item.setActionCommand(name);
            scenariosMenu2.add(item);
            item.addActionListener(new java.awt.event.ActionListener() {
                public void actionPerformed(java.awt.event.ActionEvent evt) {
                    String scenarioName = evt.getActionCommand();
                    Scenario scenario = (Scenario) god.getAvailableScenarios().get(scenarioName);
                    setScenario(scenario);
                }
            });
        }



        javax.swing.JSeparator jSeparator1 = new javax.swing.JSeparator();
        javax.swing.JMenuItem loadMenuItem = new javax.swing.JMenuItem();
        javax.swing.JMenuItem saveMenuItem = new javax.swing.JMenuItem();




        scenariosMenu2.add(jSeparator1);
        loadMenuItem.setText("Load Scenario");
        loadMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                loadMenuItemActionPerformed(evt);
            }
        });

        scenariosMenu2.add(loadMenuItem);
        saveMenuItem.setText("Save Current Scenario");
        saveMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                saveMenuItemActionPerformed(evt);
            }
        });

        scenariosMenu2.add(saveMenuItem);

        scenariosMenu2.setText("Scenarios");
        jMenuBar1.add(scenariosMenu2);

    }


    private void fileLocationMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_fileLocationMenuItemActionPerformed
         BeanPeeler bp = new BeanPeeler(fileLocation);
        bp.setTitle("Filename to be saved....");
        bp.show();
    }//GEN-LAST:event_fileLocationMenuItemActionPerformed

    private void loadMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_loadMenuItemActionPerformed
         try {
             god.loadScenario(fileLocation.getModelFile(), fileLocation.getGraphicFile());
         } catch (java.io.IOException e) {
            JOptionPane.showMessageDialog(this, e.getMessage(), "Load Error", JOptionPane.ERROR_MESSAGE);

            return;
        } catch (java.security.AccessControlException e) {
                JOptionPane.showMessageDialog(this, "Unfortunately this applet does not have permission to read from your local disk.\nFor information on how to change your permissions, and the security implications,\nplease see the help pages.", "Load Error", JOptionPane.ERROR_MESSAGE);
        }
        //@todo factor this out
        jLabel1.setText("JOrrery: " + god.getScenario());
        setPrimaryView();
        timestepSlider.setValue(50); //@todo need to find a better way of integrating this with the bean peelers
    }//GEN-LAST:event_loadMenuItemActionPerformed

    public static class FileLocation {
        private String modelFileName;
        private String graphicFileName;
        public String getModelFileName() {return modelFileName;}
        public void setModelFileName(String modelFileName) {this.modelFileName = modelFileName;}
        public String getGraphicFileName() {return graphicFileName;}
        public void setGraphicFileName(String graphicFileName) {this.graphicFileName = graphicFileName;}
        public FileLocation(String modelFileName, String graphicFileName) {
            this.modelFileName = modelFileName;
            this.graphicFileName = graphicFileName;
        }
        public java.io.File getModelFile() {return new java.io.File(modelFileName);}
        public java.io.File getGraphicFile() {return new java.io.File(graphicFileName);}
    }
    private FileLocation fileLocation = new FileLocation("C:/jorrery/jorrery.xml",
                                                         "C:/jorrery/graphics.xml");
    private void saveMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_saveMenuItemActionPerformed
            try {
                god.saveCurrentScenario(fileLocation.getModelFile(), fileLocation.getGraphicFile());
            } catch (java.io.IOException e) {
                JOptionPane.showMessageDialog(this, e.getMessage(), "Save Error", JOptionPane.ERROR_MESSAGE);
                return;
            } catch (java.security.AccessControlException e) {
                JOptionPane.showMessageDialog(this, "Unfortunately this applet does not have permission to write to your local disk.\nFor information on how to change your permissions, and the security implications,\nplease see the help pages.", "Save Error", JOptionPane.ERROR_MESSAGE);
            }
    }//GEN-LAST:event_saveMenuItemActionPerformed

    private void newTrailsViewButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_newTrailsViewButtonActionPerformed
        god.createNewTrailsView();
    }//GEN-LAST:event_newTrailsViewButtonActionPerformed

    private void timestepSliderStateChanged(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_timestepSliderStateChanged
        double dt = god.getScenario().getTimeStep();
        god.setDeltaT(dt * Math.pow(timestepSlider.getValue(),2)/Math.pow(50,2));
    }//GEN-LAST:event_timestepSliderStateChanged


    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        god.createNewTimeView();
    }//GEN-LAST:event_jButton1ActionPerformed

  private void setPrimaryView() {
    GraphicalViewPanel primaryView = god.getPrimaryView();
    centrePanel.removeAll();
    centrePanel.add(primaryView); //bit of a hack
    /*Now some real hacks to get it to repaint propertly */
    Dimension sz = this.getSize();
    setSize(new Dimension(0,0));
    setSize(sz);
  }
  private void universePrefsMenuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_universePrefsMenuActionPerformed
    god.showEditUniverseDlg();
  }//GEN-LAST:event_universePrefsMenuActionPerformed

  private void algPrefsMenuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_algPrefsMenuActionPerformed
    god.showEditAlgorithmDlg();
  }//GEN-LAST:event_algPrefsMenuActionPerformed

  private void planetPrefsMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_planetPrefsMenuItemActionPerformed
    god.showEditPlanetDlg();
  }//GEN-LAST:event_planetPrefsMenuItemActionPerformed

  private void clockPrefsMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_clockPrefsMenuItemActionPerformed
    god.showEditGodDlg();
  }//GEN-LAST:event_clockPrefsMenuItemActionPerformed

  private void newPlanetButton(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_newPlanetButton
    god.addRandomlyPlacedPlanet();
  }//GEN-LAST:event_newPlanetButton

  private void newGraphicalViewButton(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_newGraphicalViewButton
    god.createNewGraphicalView();
  }//GEN-LAST:event_newGraphicalViewButton

  private void newTextViewButton(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_newTextViewButton
    god.createNewTextView();
  }//GEN-LAST:event_newTextViewButton

  private void setScenario(Scenario scenario) {
    god.setScenario(scenario);
    jLabel1.setText("JOrrery: " + scenario);
    setPrimaryView();
    timestepSlider.setValue(50); //@todo need to find a better way of integrating this with the bean peelers
  }

  private void jMenuItem7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem7ActionPerformed
      //  new HelpAboutDlg (new javax.swing.JFrame (), true).show ();
      try {
    //todo fix this      getAppletContext().showDocument(new URL(getDocumentBase(),"help.html"));
      }
      catch (Exception e) {/*not the end of the world*/}
  }//GEN-LAST:event_jMenuItem7ActionPerformed

  God god;


  // Variables declaration - do not modify//GEN-BEGIN:variables
  private javax.swing.JMenuBar jMenuBar1;
  private javax.swing.JMenu settingsMenu;
  private javax.swing.JMenuItem clockPrefsMenuItem;
  private javax.swing.JMenuItem planetPrefsMenuItem;
  private javax.swing.JMenuItem algPrefsMenu;
  private javax.swing.JMenuItem universePrefsMenu;
  private javax.swing.JMenuItem fileLocationMenuItem;
  private javax.swing.JMenu jMenu3;
  private javax.swing.JMenuItem jMenuItem7;
  private javax.swing.JPanel mainPanel;
  private javax.swing.JLabel jLabel1;
  private javax.swing.JPanel jPanel2;
  private javax.swing.JPanel jPanel4;
  private javax.swing.JButton jButton3;
  private javax.swing.JButton jButton2;
  private javax.swing.JButton jButton1;
  private javax.swing.JButton newTrailsViewButton;
  private javax.swing.JPanel jPanel5;
  private javax.swing.JButton jButton4;
  private javax.swing.JPanel centrePanel;
  private javax.swing.JSlider timestepSlider;
  // End of variables declaration//GEN-END:variables

}
