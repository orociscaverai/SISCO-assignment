/*
 * GShadedRoundPlanet.java
 *
 * Created on 25 February 2001, 17:33
 */

package org.johndavidtaylor.jorrery;
import java.awt.Color;
import java.awt.GradientPaint;
import java.awt.Graphics2D;
/**
 *
 * @author  Default
 * @version 
 */
public class GShadedRoundPlanet extends GRoundPlanet {
  //  PointBuffer _pb = new PointBuffer(25);
    /** Creates new GShadedRoundPlanet */
    public GShadedRoundPlanet(Planet planet) {
        super(planet);
    }
    public GShadedRoundPlanet(Planet planet,Color c1,Color c2) {
        super(planet,c1,c2);
    }
    
    public GShadedRoundPlanet() {
    }
    
    public void draw(Graphics2D g) {
        //move shape
        shape.x = planet.pos.x - size/2;
        shape.y = planet.pos.y - size/2;
        g.setPaint(new GradientPaint((int) shape.x,0,colour1, (int)(shape.x+size),0,colour2,true));
        g.fill(shape);
    }   

}
