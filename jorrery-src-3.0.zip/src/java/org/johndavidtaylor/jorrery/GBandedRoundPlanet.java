/*
 * GShadedRoundPlanet.java
 *
 * Created on 25 February 2001, 17:33
 */

package org.johndavidtaylor.jorrery;
import java.awt.Color;
import java.awt.GradientPaint;
import java.awt.Graphics2D;
/**
 *
 * @author  Default
 * @version 
 */
public class GBandedRoundPlanet extends GRoundPlanet {

    /** Creates new GShadedRoundPlanet */
    public GBandedRoundPlanet(Planet planet) {
        super(planet);
    }
    public GBandedRoundPlanet(Planet planet,Color c1,Color c2) {
        super(planet,c1,c2);
    }
    
    public GBandedRoundPlanet() {
    }
    
    public void draw(Graphics2D g) {
        //move shape
        shape.x = planet.pos.x - size/2;
        shape.y = planet.pos.y - size/2;

        g.setPaint(new GradientPaint(0,(int) shape.y,colour1,0, (int)(shape.y+size/2),colour2,true));
        g.fill(shape);
    }   

}
