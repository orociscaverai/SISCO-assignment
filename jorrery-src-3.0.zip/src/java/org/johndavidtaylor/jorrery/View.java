/*
 * View.java
 *
 * Created on 15 January 2001, 15:38
 */

package org.johndavidtaylor.jorrery;

/** Implemented by all views on the model, such as the graphical
 * view showing the planet positions, the time view showing
 * elapsed time etc.
 *
 * @author JTAYLOR3
 */
public interface View {
    /** Instructs the View to reexamine the model and update its display.
     */    
    public void refresh() ;
    /** Informs the View that the underlying model has changed in
     * some way - e.g. the number of Planets in the simulation has
     * changed.
     */    
    public void universeUpdate() ;
    /** Instructs the View to dispose of itself and release any resources.
     */    
    public void dispose() ;
}

