/*
 * SHMAlgorithm.java
 *
 * Created on 21 January 2001, 13:41
 */

package org.johndavidtaylor.jorrery.algorithms;
import java.util.Iterator;
import java.util.List;

import org.johndavidtaylor.jorrery.Algorithm;
import org.johndavidtaylor.jorrery.Planet;
import org.johndavidtaylor.jorrery.TwoVec;
/**
 * The an algorithm which treats the bodies as if attached together by elastic bands.
 * @author  John Taylor
 * 
 */
public class SHMAlgorithm extends Object implements Algorithm {
    List arrayOfPlanets;
    
    /** Holds value of property springConstant. */
    private double springConstant=1.0;
    
    public SHMAlgorithm() {}
    /** Creates new SHMAlgorithm */
    public SHMAlgorithm(List arrayOfPlanets) {
        this.arrayOfPlanets = arrayOfPlanets;
    }
    public void tick(double dt){
        Iterator it = arrayOfPlanets.iterator();
        while (it.hasNext()) {
            Planet p = (Planet) it.next();
            TwoVec accel = p.pos.times(-dt*springConstant);
            p.vel.addToMe(accel.times(dt));
            p.pos.addToMe(p.vel.times(dt));
        }
    }
    
    public String toString() {
        return"SHM";
    }
    
    /** Getter for property springConstant.
     * @return Value of property springConstant.
 */
    public double getSpringConstant() {
        return springConstant;
    }
    
    /** Setter for property springConstant.
     * @param springConstant New value of property springConstant.
 */
    public void setSpringConstant(double springConstant) {
        this.springConstant = springConstant;
    }
    
    public void setPlanets(java.util.List planets) {
        this.arrayOfPlanets = planets;
    }
    
}
