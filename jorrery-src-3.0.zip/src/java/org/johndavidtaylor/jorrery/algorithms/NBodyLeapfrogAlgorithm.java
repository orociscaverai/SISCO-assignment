/*
 * SHMAlgorithm.java
 *
 * Created on 21 January 2001, 13:41
 */

package org.johndavidtaylor.jorrery.algorithms;
import java.util.Iterator;
import java.util.List;

import org.johndavidtaylor.jorrery.Algorithm;
import org.johndavidtaylor.jorrery.Planet;
import org.johndavidtaylor.jorrery.TwoVec;
/**
 * Newtonian gravity as solved by a simple leapfrog algorithm
 * @author  John Taylor
 *  
 */
public class NBodyLeapfrogAlgorithm extends Object implements Algorithm {
    List arrayOfPlanets;
    
    /** Holds value of property gravitationalConstant. */
    private double gravitationalConstant=6.664e-11*1e-18; //unit of length is (1000km)
    
    /** Holds value of property relaxationParameter. */
    private double relaxationParameter=1.0;
    
    /** Holds value of property radiusPower. */
    private int radiusPower=3;
    
    /** Creates new SHMAlgorithm */
    public NBodyLeapfrogAlgorithm(List arrayOfPlanets) {
        this.arrayOfPlanets = arrayOfPlanets;
    }
    
    public NBodyLeapfrogAlgorithm() {}
    
    //might need to change arraylist to a vector for synch reasons
    private void drift(double dt) {
        //ie move at constant velocity
        Iterator it = arrayOfPlanets.iterator();
        while (it.hasNext()) {
            Planet p = (Planet) it.next();
            p.pos.addToMe(p.vel.times(dt));
        }        
    }
    
    private TwoVec[][] forces = new TwoVec[0][0];
    private void calculateForces() {
        //watch out for unnecessary object creation
        int numPlanets = arrayOfPlanets.size();
        if (numPlanets !=forces.length) {
            forces = new TwoVec[numPlanets][numPlanets]; 
            for (int i=0;i<numPlanets;++i) {
                for (int j=0;j<numPlanets;j++) {
                    forces[i][j] = new TwoVec();
                }
            }
        }
        TwoVec relPos = new TwoVec();
        for (int i=0; i<numPlanets;++i) {
            for (int j=0; j<i;++j) {
                Planet p1 = (Planet) arrayOfPlanets.get(i);
                Planet p2 = (Planet) arrayOfPlanets.get(j);
                TwoVec.subtract(relPos,p1.pos,p2.pos);
                double R = relPos.length();
                double multiplier = gravitationalConstant * p1.mass* p2.mass / Math.pow((R+relaxationParameter),radiusPower);
                TwoVec force1 = forces[i][j];
                TwoVec force2 = forces[j][i];
                force1.setEqualTo(relPos);
                force2.setEqualTo(relPos);
                force1.timesMe(-multiplier);
                force2.timesMe(multiplier); //optimise this
            }
        }
    }
    
    private void kick(double dt) {//watch out for synch issues - what happens if number of planets has changed?
        TwoVec accel = new TwoVec();
        int numPlanets = arrayOfPlanets.size();
        for (int i = 0;i<numPlanets;++i){
            accel.x=0;accel.y=0;
            for (int j=0;j<numPlanets;++j) {
                accel.addToMe(forces[i][j]);
            }
            Planet p = (Planet) arrayOfPlanets.get(i);
            p.vel.addToMe(accel.timesMe(dt/p.mass));
        }
    }
    
    public void tick(double dt){
        //drift(dt/2);
        calculateForces();
        kick(dt);
        drift(dt);
      //  kick(dt);
    }
    
    public String toString() {
        return"Gravitational - leapfrog";
    }
    
    /** Getter for property springConstant.
     * @return Value of property springConstant.
 */
    public double getGravitationalConstant() {
        return gravitationalConstant;
    }
    
    /** Setter for property springConstant.
     * @param springConstant New value of property springConstant.
 */
    public void setGravitationalConstant(double gravitationalConstant) {
        this.gravitationalConstant = gravitationalConstant;
    }
    
    /** Getter for property relaxationParameter.
     * @return Value of property relaxationParameter.
 */
    public double getRelaxationParameter() {
        return relaxationParameter;
    }
    
    /** Setter for property relaxationParameter.
     * @param relaxationParameter New value of property relaxationParameter.
 */
    public void setRelaxationParameter(double relaxationParameter) {
        this.relaxationParameter = relaxationParameter;
    }
    
    /** Getter for property radiusPower.
     * @return Value of property radiusPower.
 */
    public int getRadiusPower() {
        return radiusPower;
    }
    
    /** Setter for property radiusPower.
     * @param radiusPower New value of property radiusPower.
 */
    public void setRadiusPower(int radiusPower) {
        this.radiusPower = radiusPower;
    }
    
    public void setPlanets(java.util.List planets) {
        this.arrayOfPlanets = planets;
    }
    
}
