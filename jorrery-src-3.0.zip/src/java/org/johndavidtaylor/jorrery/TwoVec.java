/*
 * TwoVec.java
 *
 * Created on 15 January 2001, 13:51
 */

package org.johndavidtaylor.jorrery;

/** A struct representing a 2 D vector with some basic operations defined.
 *
 * @author JTAYLOR3
 */
public class TwoVec extends Object {
    /** x coordinate
     */    
    public double x;
    /** y coordinate
     */    
    public double y;
    /** Creates new TwoVec with x = y = 0;
     */
    public TwoVec() {
        x=0.0;
        y=0.0;
    }
    /** Constructs a new TwoVec with the given coordinates.
     */    
    public TwoVec(double x, double y) {
        this.x=x;
        this.y=y;
    }
    /** Returns a new TwoVec which is equal to this vector multiplied by a scalar.
     * @param theta The scalar multiplier
     */    
    public  TwoVec times(double theta) {
        TwoVec r = new TwoVec();
        r.x = this.x * theta;
        r.y = this.y * theta;
        return r;
    }
    
    /** Adds the given vector to itself, returning a reference to itself to allow
     * operations to be chained.
     * @param v The TwoVec to be added.
     * @return this
     */    
    public TwoVec addToMe(TwoVec v) {
        this.x += v.x;
        this.y += v.y;
        return this;
    }
    
    /** Multiplies this vector by a scalar.  Like {@link times(double) } except
     * a new vector is not constructed - this one is modified.
     * @param theta the scalar
     * @return this
     */    
    public TwoVec timesMe(double theta) {
        this.x *= theta;
        this.y *= theta;
        return this;
    }
    
    /** Changes a vector to be equal to the first-the second.
     * @param ans This vector will be overwritten by the result first-second.
     * @param first
     * @param second
     */    
    public static void subtract(TwoVec ans, TwoVec first, TwoVec second) {
        ans.x = first.x - second.x;
        ans.y = first.y - second.y;
    }
    /** Makes this vector equal to the given one.
     */    
    public void setEqualTo(TwoVec vec) {
        x = vec.x;
        y = vec.y;
    }
    /** Return the length of the vector ie sqrt(x*x+y*y)
     */    
    public double length() {
        return Math.sqrt(x*x+y*y);
    }
    /** Return the square of the length
     * 
     */
    public double lengthSQ() {
    	return x*x+y*y;
    }
    
    public String toString() {
        return "("+x+","+y+")";
    }
    
}
