/*
 * ThreeEarths.java
 *
 * Created on 13 December 2001, 16:50
 */

package org.johndavidtaylor.jorrery.scenarios;
import java.awt.Color;
import java.util.ArrayList;

import org.johndavidtaylor.jorrery.AbstractScenario;
import org.johndavidtaylor.jorrery.GPlanet;
import org.johndavidtaylor.jorrery.GShadedRoundPlanet;
import org.johndavidtaylor.jorrery.Planet;
import org.johndavidtaylor.jorrery.TwoVec;
import org.johndavidtaylor.jorrery.algorithms.NBodyLeapfrogAlgorithm;
/**
 * An example of an unstable system - 3 equal bodies orbiting their mutual centre of gravity
 * @author  JTAYLOR3
 *  
 */
public class ThreeEarths extends AbstractScenario {

    /** Creates new ThreeEarths */
    public ThreeEarths() {
        double g =6.664e-11*1e-18; //N(1000km)2 kg-2
        planets = new ArrayList();
        NBodyLeapfrogAlgorithm alg = new NBodyLeapfrogAlgorithm(planets);
        alg.setRadiusPower(3);//actually = inverse square
        algorithm = alg;
        
        double m = 5.976e24; //kg
        double r = 0.3844e3; //1000km
        double phi = Math.PI/6.0;
        double theta_dot = Math.sqrt(2*g*m/(4*r*r*r*Math.cos(phi)));
        double v = r * theta_dot;
        for (int i=0;i<3;++i) {
            TwoVec pos = new TwoVec(r*Math.cos(2*i*Math.PI/3),r*Math.sin(2*i*Math.PI/3));
            TwoVec vel = new TwoVec(-v*Math.sin(2*i*Math.PI/3),v*Math.cos(2*i*Math.PI/3));
            Planet p = new Planet(pos, vel, m, "Earth"+Integer.toString(i+1));
            GPlanet gp = new GShadedRoundPlanet(p, Color.green, Color.cyan);
            gp.setSize(getUniverseMaxX()/10);
            p.setGraphic(gp);
            planets.add(p);
        }
    }
    
    public String toString() {
        return "3-body";
    }

    /** Return a suitable delta t in seconds  */
    public double getTimeStep() {
        return 25000;
    }
    
    public double getUniverseMaxX() {
        return 0.5e3; //(1000km)
    }
    
}
