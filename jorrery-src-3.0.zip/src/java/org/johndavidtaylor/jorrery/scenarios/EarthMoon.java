/*
 * TwoEarths.java
 *
 * Created on 10 July 2001, 22:19
 */

package org.johndavidtaylor.jorrery.scenarios;
import java.awt.Color;

import org.johndavidtaylor.jorrery.GRoundPlanet;
import org.johndavidtaylor.jorrery.GShadedRoundPlanet;
import org.johndavidtaylor.jorrery.Planet;
import org.johndavidtaylor.jorrery.TwoVec;
/**
 * A simple two body system based on the earth and moon
 * @author  unknown
 * 
 */
public class EarthMoon extends EmptyUniverse {
    private    double me = 5.976e24; //kg
    private    double mm = 7.366e22;
    private    double d = 0.384402e3; //km
    private    double ve;
    private    double vm;
    public EarthMoon() {

        double g =6.664e-11*1e-18; //N(1000km)2 kg-2
        double thetaDot = Math.sqrt(g*(me+mm)/(d*d*d));
//        System.out.println("Period " + 2*Math.PI/thetaDot/3600/24 + " days");
        double re = g*mm/(d*d*thetaDot*thetaDot);
        double rm = g*me/(d*d*thetaDot*thetaDot);

        ve = thetaDot * re;
        vm = thetaDot * rm;

        //Planets
        TwoVec pos1 = new TwoVec(-re,0); 
        TwoVec vel1 = new TwoVec(0,ve); 
        Planet earth = new Planet(pos1,vel1,me,"Earth");
        
        TwoVec pos2 = new TwoVec(rm,0);
        TwoVec vel2 = new TwoVec(0,-vm);
        Planet moon = new Planet(pos2,vel2,mm,"Moon");
        
        GRoundPlanet graphic1 = new GShadedRoundPlanet(earth, Color.green, Color.blue);
        GRoundPlanet graphic2 = new GShadedRoundPlanet(moon, Color.white, Color.black);
        double earthSize = maxX/10; 
        graphic1.setSize(earthSize);
        graphic2.setSize(earthSize*3476/12756); //ratio of diams in km
        
        planets.add(earth);
        planets.add(moon);
     
    }

    public double getTimeStep() {
        return 10000;
    } 
    
    public String toString() {
        return "Earth-Moon";
    }
    
    public double getTypicalPlanetMass() {
        return me;
    }
    
    public double getTypicalPlanetVelocity() {
        return ve;
    }
    
    public double getTypicalPlanetDiameter() {
        return maxX/10; //==earthsize
    }
    
}
