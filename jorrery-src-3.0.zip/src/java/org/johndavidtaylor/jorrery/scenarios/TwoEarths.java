/*
 * TwoEarths.java
 *
 * Created on 10 July 2001, 22:19
 */

package org.johndavidtaylor.jorrery.scenarios;
import java.awt.Color;

import org.johndavidtaylor.jorrery.GRoundPlanet;
import org.johndavidtaylor.jorrery.GShadedRoundPlanet;
import org.johndavidtaylor.jorrery.Planet;
import org.johndavidtaylor.jorrery.TwoVec;
/**
 * Two identical earthlike bodies stably orbiting their common centre of gravity.
 * @author  John Taylor
 * 
 */
public class TwoEarths extends EmptyUniverse {
    private    double m = 5.976e24; //kg
    private    double r = 0.3844e3; //km
    private    double v;
    
    
    public TwoEarths() {
        double g =6.664e-11*1e-18; //N(1000km)2 kg-2
        v = Math.sqrt(g*m/4/r);    
        //Planets
        TwoVec pos1 = new TwoVec(-r,0); //new TwoVec(-.3844e9,0); //m
        TwoVec vel1 = new TwoVec(0,v); //new TwoVec(0,160.9);////new TwoVec(0,16093.522);//m/s
        Planet p1 = new Planet(pos1,vel1,m,"Earth1");
        
        TwoVec pos2 = new TwoVec(r,0); //new TwoVec(0.3844e9,0); //m
        TwoVec vel2 = new TwoVec(0,-v); //new TwoVec(0,-160.9);//new TwoVec(0,-16093.522);//m/s
        Planet p2 = new Planet(pos2,vel2,m,"Earth2");
        
        GRoundPlanet graphic1 = new GShadedRoundPlanet(p1, Color.green, Color.blue);
        GRoundPlanet graphic2 = new GShadedRoundPlanet(p2, Color.blue, Color.white);
        graphic1.setSize(maxX/10);
        graphic2.setSize(maxX/10);
       
        planets.add(p1);
        planets.add(p2);
     
    }
    
   
    public String toString() {
        return "Two Earths Scenario";
    }
    
    public double getTypicalPlanetMass() {
        return m;
    }
    
    public double getTypicalPlanetVelocity() {
        return v;
    }
    public double getTypicalPlanetDiameter() {
        return maxX/10; //==earthsize
    }    
}
