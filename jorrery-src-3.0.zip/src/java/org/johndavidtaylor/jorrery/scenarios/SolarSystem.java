/*
 * SolarSystem.java
 *
 * Created on 08 August 2001, 18:08
 */

package org.johndavidtaylor.jorrery.scenarios;
import java.awt.Color;

import org.johndavidtaylor.jorrery.GBandedRoundPlanet;
import org.johndavidtaylor.jorrery.GCirclePlanet;
import org.johndavidtaylor.jorrery.GPlainPlanet;
import org.johndavidtaylor.jorrery.GRoundPlanet;
import org.johndavidtaylor.jorrery.GShadedRoundPlanet;
import org.johndavidtaylor.jorrery.Planet;
import org.johndavidtaylor.jorrery.TwoVec;
/**
 * A nine body system based on our solar system
 * @author  John Taylor
 *  
 */
public class SolarSystem extends EmptyUniverse {
     protected   class PlanetData {
            public double diameter;
            public double distance;
            public double mass;
            public String name;
            public PlanetData(String name, double diameter, double distance, double mass) {
                this.name = name;
                this.diameter = diameter;
                this.distance = distance;
                this.mass = mass;
            }
        }
    
    protected boolean _showOuterPlanets;
    protected double typ_speed; 
    protected   PlanetData[] data = {   new PlanetData("Mercury", 4920e3, 58e3, 3.303e23),
                                new PlanetData("Venus", 12100e3, 108e3, 4.8740e24),
                                new PlanetData("Earth", 12756e3, 149.6e3, 5.976e24),
                                new PlanetData("Mars", 6800e3, 228e3, 6.421e23),
                                new PlanetData("Jupiter", 142700e3, 778e3, 1.899e27),
                                new PlanetData("Saturn", 120800e3, 1428e3, 5.686e26),
                                new PlanetData("Uranus", 52900e3, 2872e3, 8.66e25),
                                new PlanetData("Neptune", 49200e3, 4498e3, 1.03e26),
                                new PlanetData("Pluto", 2400e3, 5910e3, 6.6e21)};
    protected    PlanetData sunData = new PlanetData("Sun", 1392000e3, 0, 2e30);

    
    private String title;
    
    /** Creates new SolarSystem */
    public SolarSystem(boolean sunTrueSize, boolean showOuterPlanets) {
        _showOuterPlanets = showOuterPlanets;
        maxX = showOuterPlanets ? 6000e3 : 228e3; //rough solar system size
                
        Planet sun = new Planet(new TwoVec(0,0), new TwoVec(0,0), sunData.mass, sunData.name);

        double sunSize = maxX/5; //might have to rescale this one.
        double earthSize=0;
        if (showOuterPlanets) {
            title = "Solar System";
        } 
        else {
            title = "Inner Solar System";
        }
        if (sunTrueSize) {
            title+=" (sun to scale)";
        }
        else {
            title+=" (sun not to scale)";
        }
        
        if (sunTrueSize) {
            earthSize =  sunSize * data[2].diameter/sunData.diameter;
        }
        else if (!sunTrueSize && showOuterPlanets) {
            sunSize = maxX/7;
            double jupiterSize = maxX/10; //make jupiter reasonable, and scale the rest
            earthSize = data[2].diameter / data[4].diameter * jupiterSize;
        }
        else if (!sunTrueSize && !showOuterPlanets) {
            earthSize = maxX/6; //earth a reasonable size, the rest to scale
        }
        GRoundPlanet sunGraphic = showOuterPlanets ? (GRoundPlanet) new GCirclePlanet(sun, Color.yellow, Color.black)  : (GRoundPlanet) new GPlainPlanet(sun, Color.yellow, Color.black);
        sunGraphic.setSize(sunSize);
        sun.setGraphic(sunGraphic);

        double g =6.664e-11*1e-18; //N(1000km)2 kg-2
        for (int i = 0; i< (showOuterPlanets ? data.length : 4);++i) {
            double d = data[i].distance;
            double thetaDot = Math.sqrt(g*sunData.mass/(d*d*d));
            //System.out.println("Period of " + data[i].name+" = " + (2*Math.PI/thetaDot)/3600/24 + " days");
            TwoVec pos = new TwoVec(d,0);
            TwoVec vel = new TwoVec(0, thetaDot*d);
            if (i==2) typ_speed = thetaDot*d;
            Planet p = new Planet(pos, vel, data[i].mass, data[i].name);
            planets.add(p);
        }
        
        GRoundPlanet gplanets[] = new GRoundPlanet[data.length];
        gplanets[0] = new GShadedRoundPlanet((Planet)planets.get(0), Color.gray, Color.white); //merc
        gplanets[1] = new GShadedRoundPlanet((Planet)planets.get(1), Color.white, Color.blue); //ven
        gplanets[2] = new GShadedRoundPlanet((Planet)planets.get(2), Color.green, Color.blue); //earth
        gplanets[3] = new GPlainPlanet((Planet)planets.get(3), Color.red, Color.black); //mars
        if (showOuterPlanets) {
            gplanets[4] = new GBandedRoundPlanet((Planet)planets.get(4), Color.yellow, Color.red); //jupiter
            gplanets[5] = new GBandedRoundPlanet((Planet)planets.get(5), Color.orange, Color.yellow); //saturn
            gplanets[6] = new GShadedRoundPlanet((Planet)planets.get(6), Color.blue, Color.green); //uranus
            gplanets[7] = new GBandedRoundPlanet((Planet)planets.get(7), Color.blue, Color.cyan); //neptune 
            gplanets[8] = new GPlainPlanet((Planet)planets.get(8), Color.white, Color.black); //pluto
        }
        
        for (int i = 0; i< (showOuterPlanets ? data.length : 4);++i) {
            Planet p = (Planet) planets.get(i);
            double diam = earthSize * data[i].diameter / data[2].diameter;
            gplanets[i].setSize(diam);
           // System.out.println("Diameter :" + diam);
            p.setGraphic(gplanets[i]);
        }
        planets.add(sun);        
    }
    
    public String toString() {
        return title;
    }
    
    public double getTypicalPlanetMass() {
        return data[2].mass;
    }    
    
    public double getTypicalPlanetVelocity() {
        return typ_speed;
    }    
    
    public double getTypicalPlanetDiameter() {
        return maxX/6; //==earthsize
    }
    
     public double getTimeStep() {
        return _showOuterPlanets ? 500000 : 100000;
    }  
}
