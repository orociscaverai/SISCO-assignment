/*
 * EmptyUniverse.java
 *
 * Created on 10 July 2001, 22:18
 */

package org.johndavidtaylor.jorrery.scenarios;
import java.util.ArrayList;
import java.util.List;

import org.johndavidtaylor.jorrery.AbstractScenario;
import org.johndavidtaylor.jorrery.Algorithm;
import org.johndavidtaylor.jorrery.algorithms.NBodyLeapfrogAlgorithm;
/**
 *A blank scenario with no planets.
 * @author  unknown
 * 
 */
public class EmptyUniverse extends AbstractScenario {
    
    protected double maxX = 0.5e3; //(1000km)
  //  protected double g;
    
   /* public double getGravConst() {
        return  6.664e-11*1e-18; //N(1000km)2 kg-2
    }*/
    /** Creates new TwoEarths */
    public EmptyUniverse() {
        planets = new ArrayList();
   //     g = getGravConst();
        NBodyLeapfrogAlgorithm alg = new NBodyLeapfrogAlgorithm(planets);
   //     alg.setGravitationalConstant(g); //Nm2 kg-2
        alg.setRadiusPower(3);//actually = inverse square
        
        algorithm = alg;
    }

    public Algorithm getAlgorithm() {
        return algorithm;
    }
    
    public List getPlanets() {
        return planets;
    }
    
    public double getUniverseMaxX() {
        return maxX;
    }
    
    public String toString() {
        return "Empty Universe";
    }
    
    public double getTimeStep() {
        return 50000;
    }  
    

    
}
