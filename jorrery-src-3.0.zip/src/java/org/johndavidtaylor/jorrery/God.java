/*
 * God.java
 *
 * Created on 15 January 2001, 14:46
 */

package org.johndavidtaylor.jorrery;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.johndavidtaylor.beans.beanpeeler.BeanPeeler;
import org.johndavidtaylor.jorrery.scenarios.EarthMoon;
import org.johndavidtaylor.jorrery.scenarios.EmptyUniverse;
import org.johndavidtaylor.jorrery.scenarios.SolarSystem;
import org.johndavidtaylor.jorrery.scenarios.ThreeEarths;
import org.johndavidtaylor.jorrery.scenarios.TwoEarths;
import org.johndavidtaylor.jorrery.views.EnergyTextView;
import org.johndavidtaylor.jorrery.views.GraphicalView;
import org.johndavidtaylor.jorrery.views.GraphicalViewPanel;
import org.johndavidtaylor.jorrery.views.TimeView;
/**
 *
 * @author  JTAYLOR3
 * @version 
 */
public class God implements Runnable {
    private Universe universe;
    
    /** Creates new form God */
    public God() {
        initialiseScenarios();
        Thread ut = new Thread(this);
        ut.start();
    }

 

  private void editGodActionPerformed(java.awt.event.ActionEvent evt) {
    showEditGodDlg();
  }
  public void showEditGodDlg() {
        BeanPeeler bp = new BeanPeeler(this);
        bp.setTitle("Clock properties");
        bp.show();    
  }
  private void editUniverseActionPerformed(java.awt.event.ActionEvent evt) {
      showEditUniverseDlg();
  }
  public void showEditUniverseDlg() {
      BeanPeeler bp = new BeanPeeler(universe);
      bp.setTitle("Universe Properties");
      bp.show();
  }
  private void editAlgorithmActionPerformed(java.awt.event.ActionEvent evt) {
      showEditAlgorithmDlg();
  }
  public void showEditAlgorithmDlg() {
        BeanPeeler bp = new BeanPeeler(universe.getAlgorithm());
        bp.setTitle("Algorithm Properties");
        bp.show();    
  }
  private void editPlanetCreationActionPerformed(java.awt.event.ActionEvent evt) {
        showEditPlanetDlg();
  }
  public void showEditPlanetDlg() {
        BeanPeeler bp = new BeanPeeler(new PlanetFactory());
        bp.setTitle("Planet Creation Properties");
        bp.show();
  }
  private void newPlanetBtnActionPerformed(java.awt.event.ActionEvent evt) {
        addRandomlyPlacedPlanet();
  }

  private void newGraphicalBtnActionPerformed(java.awt.event.ActionEvent evt) {
        createNewGraphicalView();
  }

  private void newTextViewBtnActionPerformed(java.awt.event.ActionEvent evt) {
        createNewTextView();
  }

  public void addRandomlyPlacedPlanet() {
            Planet p = PlanetFactory.getRandom();

            universe.getVectorOfPlanets().add(p);
            Iterator it = vectorOfViews.iterator();
            while (it.hasNext()) {
                ((View) it.next()).universeUpdate();
            }    
  }
  
  public TimeView createNewTimeView() {
        TimeView view = new TimeView(universe);
        view.show();
        createNewView(view);
        return view;      
  }
  public View createNewTextView() {
        //TextView view = new TextView(universe);
		EnergyTextView view = new EnergyTextView(universe);
        view.show();
        createNewView(view);
        return view;
  }
 public GraphicalView createNewTrailsView() {
        GraphicalView view = new GraphicalView(universe, GraphicalViewPanel.TRAILS);
        view.show();
        createNewView(view);
        return view;
  }
  public GraphicalView createNewGraphicalView(boolean doShow) {
        GraphicalView view = new GraphicalView(universe);
        if (doShow) view.show();
        createNewView(view);
        return view;
  }
  public GraphicalViewPanel createNewGraphicalViewPanel() {
        GraphicalViewPanel view = new GraphicalViewPanel(universe);
        createNewView(view);
        return view;
  }
  public GraphicalView createNewGraphicalView() {
        return createNewGraphicalView(true);
  }
  private void createNewView(View view){
        vectorOfViews.add(view);
  }

  /** Getter for property deltaT.
   * @return Value of property deltaT.
 */
  public double getDeltaT() {
      return deltaT;
  }
  
  /** Setter for property deltaT.
   * @param deltaT New value of property deltaT.
 */
  public void setDeltaT(double deltaT) {
      this.deltaT = deltaT;
  }
  
  /** Getter for property millisecondsPerStep.
   * @return Value of property millisecondsPerStep.
 */
  public int getMillisecondsPerStep() {
      return millisecondsPerStep;
  }
  
  /** Setter for property millisecondsPerStep.
   * @param millisecondsPerStep New value of property millisecondsPerStep.
 */
  public void setMillisecondsPerStep(int millisecondsPerStep) {
      this.millisecondsPerStep = millisecondsPerStep;
  }
  
 


    public Collection vectorOfViews = new ArrayList();    

    /** Holds value of property deltaT. */
    private double deltaT=0.1;
    
    /** Holds value of property millisecondsPerStep. */
    private int millisecondsPerStep=10;
    private boolean doRun = false;
    private boolean alive = true;
       
        public void run() {
            while(alive) {
                if (doRun) universe.tick(deltaT);
                Thread.yield();  
                try {
                    Thread.sleep(millisecondsPerStep);
                }
                catch(InterruptedException e) {
                }
            }
        }     

        public void suspend() {
            doRun = false;
        }
        
        public void unsuspend() {
            doRun = true;
        }
        
        public void die() {
             Iterator it = vectorOfViews.iterator();
             while (it.hasNext()) {
                View v = (View) it.next();
                v.dispose();
             }
             alive = false;
        }
        
        private Scenario scenario;
        public Scenario getScenario() {
            return scenario;
        }
        
        public void setScenario(Scenario scenario) {
            this.scenario = scenario;
            Iterator it = vectorOfViews.iterator();
            while(it.hasNext()) {
                ((View)it.next()).dispose();
            }
            vectorOfViews.clear();
            suspend();
           
            universe = new Universe(scenario.getAlgorithm(), scenario.getPlanets(), scenario. getUniverseMaxX());
            universe.setArrayOfPlanets(scenario.getPlanets());
            
           
            primaryView = createNewGraphicalViewPanel();
            
            setDeltaT(scenario.getTimeStep());
            
            //bit weird mixture of static and nonstatic here - needs fixing
            PlanetFactory pf = new PlanetFactory();
            pf.setNewPlanetMass(scenario.getTypicalPlanetMass());
            pf.setNewPlanetMaxDistance(scenario.getUniverseMaxX());
            pf.setNewPlanetMaximumVelocity(scenario.getTypicalPlanetVelocity());
            pf.setNewPlanetDiameter(scenario.getTypicalPlanetDiameter());
            
            // Now would definitely be a good time
            System.gc();
            unsuspend();
        }
        GraphicalViewPanel primaryView;
        
        /** Holds value of property availableScenarios. */
        private Map availableScenarios = new HashMap();
        
        public GraphicalViewPanel getPrimaryView() {
            return primaryView;
        }
        
        public void saveCurrentScenario(java.io.File mFile, java.io.File gFile) throws IOException {
            DataOutputStream dos1 = new DataOutputStream(new BufferedOutputStream(new FileOutputStream(mFile)));
            DataOutputStream dos2 = new DataOutputStream(new BufferedOutputStream(new FileOutputStream(gFile)));
            org.johndavidtaylor.jorrery.io.XMLConverter xml = new org.johndavidtaylor.jorrery.io.XMLConverter(getScenario());

            xml.write(dos1, dos2);
            
            dos1.close();
            dos2.close();

        }
        
        public void loadScenario(java.io.File mFile, java.io.File gFile) throws IOException {
            suspend();
            DataInputStream dis1 = new DataInputStream(new BufferedInputStream(new FileInputStream(mFile)));
            DataInputStream dis2 = new DataInputStream(new BufferedInputStream(new FileInputStream(gFile)));
            org.johndavidtaylor.jorrery.io.XMLConverter xml = new org.johndavidtaylor.jorrery.io.XMLConverter();
            try {
                setScenario(xml.read(dis1, dis2));
                dis1.close();
                dis2.close();
            } catch (org.johndavidtaylor.jorrery.io.XMLIOException e) {
                throw new IOException(e.getMessage());
            } finally {
                unsuspend();
            }
        }
        
        /** Indexed getter for property availableScenarios.
         * @param index Index of the property.
         * @return Value of the property at <CODE>index</CODE>.
         */
        public Scenario getAvailableScenarios(Object key) {
            return (Scenario) availableScenarios.get(key);
        }
        
        /** Getter for property availableScenarios.
         * @return Value of property availableScenarios.
         */
        public Map getAvailableScenarios() {
            return availableScenarios;
        }
        
        /** Indexed setter for property availableScenarios.
         * @param index Index of the property.
         * @param availableScenarios New value of the property at <CODE>index</CODE>.
         */
        public void setAvailableScenarios(Object index, Scenario availableScenarios) {
            this.availableScenarios.put(index, availableScenarios);
        }
        
        /** Setter for property availableScenarios.
         * @param availableScenarios New value of property availableScenarios.
         */
        public void setAvailableScenarios(Map availableScenarios) {
            this.availableScenarios = availableScenarios;
        }
        
        public Scenario getInitialScenario() {
            return initialScenario;
        }
        private Scenario initialScenario;
        private void initialiseScenarios() {
            Scenario[] all = {
                new SolarSystem(false, false),
                new SolarSystem(true, false),
                new SolarSystem(false, true),
                new SolarSystem(true, true),
                new EarthMoon(),
                new TwoEarths(),
                new ThreeEarths(),
                new EmptyUniverse() 
            };
            
            initialScenario = all[0];
            for (int i = 0; i<all.length;++i) {
                availableScenarios.put(all[i].toString(), all[i]);
            }  
        }
        
}

