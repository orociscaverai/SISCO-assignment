/*
 * AbstractScenario.java
 *
 * Created on 13 December 2001, 16:42
 */

package org.johndavidtaylor.jorrery;
import java.util.Iterator;
import java.util.List;
/**
 * Useful base clase class for Scenarios, with the boring methods filled in.
 * @author  JTAYLOR3
 */
public abstract class AbstractScenario implements Scenario {
    protected List planets;
    protected Algorithm algorithm;
    /** Creates new AbstractScenario */
    public AbstractScenario() {
    }

    private interface Averager {
        double getProp(Planet p);
    }
    private double average(Averager av) {
        Iterator it = planets.iterator();
        double total = 0;
        while (it.hasNext()) {
            total+= av.getProp((Planet)it.next());
        }
        total/=planets.size();
        return total;
    }
    
    public double getTypicalPlanetDiameter() {
        return average(new Averager() {
            public double getProp(Planet p) {return p.getGraphic().getSize();}
        });
    }
    
    public double getTypicalPlanetMass() {
        return average(new Averager() {
            public double getProp(Planet p) {return p.getMass();}
        });        
    }
    
    public double getTypicalPlanetVelocity() {
        return average(new Averager() {
            public double getProp(Planet p) {return p.vel.length();}
        });        
    }
    
    public java.util.List getPlanets() {
        return planets;
    }
    
    public Algorithm getAlgorithm() {
        return algorithm;
    }
    
}
