/*
 * Algorithm.java
 *
 * Created on 21 January 2001, 13:40
 */

package org.johndavidtaylor.jorrery;

/** All numerical algorithms implement this interface.  Classes
 * implementing the interface should be passed a reference to
 * the collection of planets, if they're to do anything interesting.
 * The framework calls {@link tick(double)} when it wishes the algorithm
 * to calculate the next time step.  If the algorithm is
 * multistep then it will need to be responsible for caching the
 * planets' data at previous timesteps.  Furthermore, the timestep
 * is expected to be constant so adaptive timestep methods are
 * not allowed - they'd cause the simulation to speed up and slow down!
 *
 *
 * @author John Taylor
 */
public interface Algorithm  {

    /** Called by the framework to calculate the planetary positions at
     * the new timestep.
     * @param dt The timestep.
     */    
    public void tick(double dt);

    public void setPlanets(java.util.List planets);
    
}
