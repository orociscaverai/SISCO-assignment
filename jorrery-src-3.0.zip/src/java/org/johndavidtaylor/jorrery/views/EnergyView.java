/*
 * Created on 27-Sep-2003
 *
 */
package org.johndavidtaylor.jorrery.views;

import org.johndavidtaylor.jorrery.Planet;
import org.johndavidtaylor.jorrery.TwoVec;
import org.johndavidtaylor.jorrery.Universe;
import org.johndavidtaylor.jorrery.View;
import java.util.*;

/**
 * @author John Taylor
 *
 * This help class will examine the universe and try to tot
 * up the potential and kinetic energies.  It's not reponsible for 
 * displaying the results though.
 */
public class EnergyView implements View {
	/* (non-Javadoc)
	 * @see com.johndavid_taylor.nbody.View#refresh()
	 */
	public void refresh() {
		// TODO Auto-generated method stub
	}
	/* (non-Javadoc)
	 * @see com.johndavid_taylor.nbody.View#universeUpdate()
	 */
	public void universeUpdate() {
		// TODO Auto-generated method stub
	}
	/* (non-Javadoc)
	 * @see com.johndavid_taylor.nbody.View#dispose()
	 */
	public void dispose() {
		// TODO Auto-generated method stub
	}
	private Universe universe;
	public EnergyView(Universe universe) {
		this.universe=universe;
	}
	public double getTotalKE() {
		/** Calculate the total kinetic energy in the universe
		 * 
		 */
		List planets = universe.getVectorOfPlanets();
		Iterator it = planets.iterator();
		double KE=0;
		while (it.hasNext()) {
			Planet planet = (Planet) it.next();
			KE+=calculateKE(planet);
		}
		return KE;
	}
	public double getPlanetKE(Planet planet) {
		return calculateKE(planet);
	}
	public double getPlanetPE(Planet planet) {
		return 0;//return calculatePE(planet);
	}	
	private double calculateKE(Planet planet) {
		/** There's a good question as to whether this method
		 *  should be here, or in planet.  Not very OO to put it here.
		 * The main argument for putting it here is that we can't isolate
		 * the method for the PE in a planet (or could we? could pass it an array of planets...)
		 */
		TwoVec vel = planet.vel;
		double KE = 0.5* planet.getMass() * vel.lengthSQ();
		return KE;
	}
	public double getTotalPE() {
		double PE=0;
		return PE;
	}
	/**
	 *  return the total energy in the system
	 */
	public double getTotalEnergy() {
		return getTotalPE()+getTotalKE();
	}
	
	
}
