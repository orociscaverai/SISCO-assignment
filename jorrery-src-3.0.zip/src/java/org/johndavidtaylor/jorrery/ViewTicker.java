package org.johndavidtaylor.jorrery;

public class ViewTicker extends Thread {
    private View myview;
    
/** Holds value of property refreshInterval.  */
    private int refreshInterval = 50;
    
    public ViewTicker(View view) {
        this.myview = view;
    }
    
    private boolean alive = true;
    public void die() {
        alive = false;
    }
    
        public void run() {
            while(alive) {
                myview.refresh();
                Thread.yield();
                try {
                    sleep(refreshInterval);
                }
                catch(InterruptedException e) {
                }
            }
        }
        
/** Getter for property refreshInterval.
 * @return Value of property refreshInterval.
 */
        public int getRefreshInterval() {
            return refreshInterval;
        }
        
/** Setter for property refreshInterval.
 * @param refreshInterval New value of property refreshInterval.
 */
        public void setRefreshInterval(int refreshInterval) {
            this.refreshInterval = refreshInterval;
        }
        
        
}

