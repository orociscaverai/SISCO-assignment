/*
 * GShadedRoundPlanet.java
 *
 * Created on 25 February 2001, 17:33
 */

package org.johndavidtaylor.jorrery;
import java.awt.Color;
import java.awt.Graphics2D;
/**
 *
 * @author  Default
 * @version 
 */
public class GPlainPlanet extends GRoundPlanet {

    /** Creates new GShadedRoundPlanet */
    public GPlainPlanet(Planet planet) {
        super(planet);
    }
    public GPlainPlanet(Planet planet,Color c1,Color c2) {
        super(planet,c1,c2);
    }
    
    public GPlainPlanet() {
    }
    
    public void draw(Graphics2D g) {
        //move shape
        shape.x = planet.pos.x - size/2;
        shape.y = planet.pos.y - size/2;

        g.setColor(colour1);
        g.fill(shape);
    }   

}
