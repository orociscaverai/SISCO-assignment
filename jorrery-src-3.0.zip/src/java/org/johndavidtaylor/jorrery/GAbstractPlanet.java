/*
 * GAbstractPlanet.java
 *
 * Created on 11 December 2001, 16:58
 */

package org.johndavidtaylor.jorrery;
import java.awt.Color;
/**
 *  Useful abstract class that implements all the boring methods in interface GPlanet
 * @author  JTAYLOR3
 */
public abstract class GAbstractPlanet implements GPlanet{

    /** Creates new GAbstractPlanet */
    public GAbstractPlanet() {
    }
    
    public void setPlanet(Planet p) {
        this.planet = p;
    }
    
   
    /** Getter for property colour2.
     * @return Value of property colour2.
     */
    public Color getColour2() {
        return colour2;
    }
    
    /** Getter for property colour1.
     * @return Value of property colour1.
     */
    public Color getColour1() {
        return colour1;
    }
    
    /** Setter for property colour1.
     * @param colour1 New value of property colour1.
     */
    public void setColour1(Color colour1) {
        this.colour1 = colour1;
    }
    
    /** Setter for property colour2.
     * @param colour2 New value of property colour2.
     */
    public void setColour2(Color colour2) {
        this.colour2 = colour2;
    }
    
    public void setSize(double size) {
        this.size = size;
    }
    
    public double getSize() {
        return this.size;
    }
    
    protected Planet planet;
    protected Color colour1;
    protected Color colour2;
    protected double size;
    
    

}
