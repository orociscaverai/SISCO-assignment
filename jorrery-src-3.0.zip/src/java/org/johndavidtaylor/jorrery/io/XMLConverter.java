/*
 * XMLConverter.java
 *
 * Created on 10 December 2001, 11:48
 */

package org.johndavidtaylor.jorrery.io;
import org.johndavidtaylor.jorrery.*;
import java.awt.Color;

import org.jdom.*;
import org.jdom.input.*;
import org.jdom.output.*;
import java.io.*;
/**
 * Converts {@link Scenario} objects to and from xml.
 * This class uses the jdom API www.jdom.org.  The class converts the Scenario to and from xml which is sent/received
 * from two streams.
 *
 * @author  JTAYLOR3
 * 
 */
public class XMLConverter {
    private Scenario _scenario;
    /** Creates new XMLConverter */
    public XMLConverter(Scenario scenario) {
        _scenario = scenario;
    }
    public XMLConverter() {
        
    }
    
    private final String ROOTELM = "nbody";
    private final String SCENARIO = "scenario";
    private final String UNIVERSE = "universe";
    private final String UNISIZE = "size";
    private final String ALGORITHM = "algorithm";
    private final String TIMESTEP = "timestep";
    private final String BODY = "body";
    private final String VEL = "vel";
    private final String POS = "pos";
    private final String MASS = "mass";
    private final String NAME = "name";
    private final String X = "x";
    private final String Y = "y";
    private final String Z = "z";
    private final String GRAPHIC = "graphic";
    private final String COL1 = "colour1";
    private final String COL2 = "colour2";
    private final String SIZE = "diameter";
        
    
    
    public void write(OutputStream model, OutputStream graphics) throws IOException {
        /** Write out physical part of data */
        if (model!=null) {
            Element unielm = new Element(UNIVERSE);

            unielm.setAttribute(UNISIZE, Double.toString(_scenario.getUniverseMaxX()));
            Algorithm algorithm = _scenario.getAlgorithm();
            Element algElm = new Element(ALGORITHM);
            unielm.addContent(algElm);
            algElm.addContent(new Comment("The Class of the algorithm used for this simulation"));
            algElm.addContent(_scenario.getAlgorithm().getClass().getName());

            algElm.setAttribute(TIMESTEP , Double.toString(_scenario.getTimeStep()));

            java.util.List planets = _scenario.getPlanets();
            for (int i = 0; i<planets.size(); ++i) {
                Planet p = (Planet) planets.get(i);
                Element body = new Element(BODY);
                body.addContent(new Element(NAME).addContent(p.getName()));
                Element pos = new Element(POS);
                Element vel = new Element(VEL);
                body.addContent(pos).addContent(vel);
                pos.addContent(new Element(X).addContent(Double.toString(p.pos.x)));
                pos.addContent(new Element(Y).addContent(Double.toString(p.pos.y)));
                pos.addContent(new Element(Z).addContent(Double.toString(0)).addContent(new Comment("no z value (2D)")));
                vel.addContent(new Element(X).addContent(Double.toString(p.vel.x)));
                vel.addContent(new Element(Y).addContent(Double.toString(p.vel.y)));
                vel.addContent(new Element(Z).addContent(Double.toString(0)).addContent(new Comment("no z value (2D)"))); 
                body.addContent(new Element(MASS).addContent(Double.toString(p.getMass())));
                unielm.addContent(body);
            }


            Document document = new Document(new Element(ROOTELM));
            Element scenario = new Element(SCENARIO);
            scenario.addContent(new Element(NAME).addContent(_scenario.toString()));
            scenario.addContent(unielm);

            document.getRootElement().addContent(new Comment("The following file represents the physical part of a Scenario Object"));
            document.getRootElement().addContent(scenario);



            XMLOutputter output = new XMLOutputter("\t",true);
            output.output(document, model);
        }
        
        /* Write out graphics config */
        if (graphics!=null) {
            Document document = new Document(new Element(ROOTELM));
            document.getRootElement().addContent(new Comment("The following file represents the graphical part of a Scenario Object"));
            java.util.List planets = _scenario.getPlanets();
            for (int i = 0; i<planets.size(); ++i) {
                Planet p = (Planet) planets.get(i);
                Element body = new Element(BODY);
                body.addContent(new Element(NAME).addContent(p.getName()));
                body.addContent(new Element(GRAPHIC).addContent(p.getGraphic().getClass().getName()));
                body.addContent(new Element(SIZE).addContent(Double.toString(p.getGraphic().getSize())));
                body.addContent(new Element(COL1).addContent(Integer.toHexString(0xFFFFFF & p.getGraphic().getColour1().getRGB())));
                body.addContent(new Element(COL2).addContent(Integer.toHexString(0xFFFFFF & p.getGraphic().getColour2().getRGB())));
                document.getRootElement().addContent(body);
            }

            XMLOutputter output = new XMLOutputter("\t",true);
            output.output(document, graphics);            
        }
    }
    
    public synchronized Scenario read(InputStream model, InputStream graphics) throws XMLIOException {
        try {
            Document document = new SAXBuilder("org.apache.crimson.parser.XMLReaderImpl").build(model);
            Element scenario = document.getRootElement().getChild(SCENARIO);
            XMLScenario newScenario = new XMLScenario(scenario.getChild(NAME).getText());

            Element universe = scenario.getChild(UNIVERSE);
            newScenario.setUniverseMaxX(Double.parseDouble(universe.getAttributeValue(UNISIZE)));

            Element algorithm = universe.getChild(ALGORITHM);
            newScenario.setTimeStep(Double.parseDouble(algorithm.getAttributeValue(TIMESTEP)));


            /** Assume the planets are serial for the moment - work on nested ones later*/
            java.util.List planetsXML = universe.getChildren(BODY);
            java.util.List planets = new java.util.ArrayList();

            double totalMass = 0;
            double totalVel = 0;

            double uniSize = newScenario.getUniverseMaxX();
            for (int i=0; i<planetsXML.size();++i) {
                Element planet = (Element)planetsXML.get(i);
                String name = planet.getChild(NAME).getText();
                double mass = Double.parseDouble(planet.getChild(MASS).getText());
                TwoVec pos = new TwoVec(Double.parseDouble(planet.getChild(POS).getChild(X).getText()), 
                                        Double.parseDouble(planet.getChild(POS).getChild(Y).getText()));
                TwoVec vel = new TwoVec(Double.parseDouble(planet.getChild(VEL).getChild(X).getText()), 
                                        Double.parseDouble(planet.getChild(VEL).getChild(Y).getText()));           
                Planet p = new Planet(pos, vel, mass, name);          

                //System.out.println(p + "\n" + p.pos + "\n" + p.vel + "\n" + p.mass);

                /* Until a graphical file is available, all planets will be plain white/black with d = size/20 */
                GRoundPlanet graphic = new GPlainPlanet(p, Color.white, Color.black);
                graphic.setSize(uniSize/20);
                p.setGraphic(graphic);
                planets.add(p);
                totalMass += p.getMass();
                totalVel += (p.vel.length());
            }
            newScenario.setPlanets(planets);
            newScenario.setTypicalPlanetMass(totalMass/planets.size());
            newScenario.setTypicalPlanetVelocity(totalVel/planets.size());
            newScenario.setTypicalPlanetDiameter(uniSize/20);


            String algClass = algorithm.getText().trim();
            Algorithm alg = (Algorithm) Class.forName(algClass).newInstance();
            newScenario.setAlgorithm(alg);
            alg.setPlanets(planets);
            //System.out.println(newScenario.getTimeStep());

            /*Set graphics if possible */
            if (graphics!=null) {
                document = new SAXBuilder("org.apache.crimson.parser.XMLReaderImpl").build(graphics);
                Element nbody = document.getRootElement();
                java.util.List bodies = nbody.getChildren(BODY);
                java.util.Map map = new java.util.HashMap();
                for (int i =0;i<bodies.size(); ++i) {
                    Element body = (Element) bodies.get(i);
                    map.put(body.getChild(NAME).getText(), body);
                }
                System.out.println();
                for (int i =0; i<planets.size();++i) {
                    Planet p = (Planet) planets.get(i);
                    Element body = (Element) map.get(p.getName());
                    if (body!=null) {
                        String gClass = body.getChild(GRAPHIC).getTextTrim();
                        int c1 = Integer.parseInt(body.getChild(COL1).getText(),16);
                        int c2 = Integer.parseInt(body.getChild(COL2).getText(),16);
                        double size = Double.parseDouble(body.getChild(SIZE).getText());
                        System.out.println(p.getName()+" "+ gClass);
                        GPlanet  grp = (GPlanet) Class.forName(gClass).newInstance();
                        grp.setColour1(new Color(c1));
                        grp.setColour2(new Color(c2));
                        grp.setPlanet(p);
                        grp.setSize(size);
                        p.setGraphic(grp);
                    }
                }
            }
            
            
            _scenario = newScenario;
            return _scenario;
        } catch (ClassNotFoundException c) {
            throw new XMLIOException("Could not find algorithm class - please check your xml and that the class exists");
        } catch (InstantiationException c) {
            throw new XMLIOException("Could not instantiate algorithm class - please check your xml and that the class exists");
        } catch (IllegalAccessException c) {
            throw new XMLIOException("Could not instantiate algorithm class - please check your xml and that the class exists");
        } catch (JDOMException c) {
            throw new XMLIOException("There was a problem parsing the XML : "+c.getMessage()+" - please check your xml");
        } catch (IOException c) {// @TODO what to do here?
            throw new XMLIOException("?? "+c.getMessage()+" - please check your xml");
        }
    }
    
    public synchronized Scenario getScenario() {return _scenario;}
    
    public static class XMLScenario implements Scenario {

            private Algorithm algorithm;

            private java.util.List planets;

            private double timeStep;

            private double typicalPlanetDiameter;

            private double typicalPlanetMass;

            private double typicalPlanetVelocity;

            private double universeMaxX;

            private String name;

            public XMLScenario(String name) {
                this.name = name;
            }

            /** Return a suitable delta t in seconds   */
            public double getTimeStep() {
                return timeStep;
            }

            public double getTypicalPlanetDiameter() {
                return typicalPlanetDiameter;
            }

            public double getTypicalPlanetMass() {
                return typicalPlanetMass;
            }

            public double getTypicalPlanetVelocity() {
                return typicalPlanetVelocity;
            }

            public java.util.List getPlanets() {
                return planets;
            }

            public Algorithm getAlgorithm() {
                return algorithm;
            }

            public double getUniverseMaxX() {
                return universeMaxX;
            }

            public void foo() {}

            public void setAlgorithm(Algorithm algorithm) {this.algorithm = algorithm;}

            public void setPlanets(java.util.List planets) {this.planets = planets;}

            public void setTimeStep(double timeStep) {this.timeStep = timeStep;}

            public void setTypicalPlanetDiameter(double typicalPlanetDiameter) {this.typicalPlanetDiameter = typicalPlanetDiameter;}

            public void setTypicalPlanetMass(double typicalPlanetMass) {this.typicalPlanetMass = typicalPlanetMass;}

            public void setTypicalPlanetVelocity(double typicalPlanetVelocity) {this.typicalPlanetVelocity = typicalPlanetVelocity;}

            public void setUniverseMaxX(double universeMaxX) {this.universeMaxX = universeMaxX;}

            public String toString() {return name;}

        }


}


