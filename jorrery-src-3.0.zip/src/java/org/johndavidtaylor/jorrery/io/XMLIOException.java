/*
 * XMLIOException.java
 *
 * Created on 11 December 2001, 15:10
 */

package org.johndavidtaylor.jorrery.io;

/**
 *
 * @author  JTAYLOR3
 * @version 
 */
public class XMLIOException extends java.lang.Exception {

    /**
     * Creates new <code>XMLIOException</code> without detail message.
     */
    public XMLIOException() {
    }


    /**
     * Constructs an <code>XMLIOException</code> with the specified detail message.
     * @param msg the detail message.
     */
    public XMLIOException(String msg) {
        super(msg);
    }
}


