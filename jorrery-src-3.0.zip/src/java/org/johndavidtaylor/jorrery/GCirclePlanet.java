/*
 * GShadedRoundPlanet.java
 *
 * Created on 25 February 2001, 17:33
 */

package org.johndavidtaylor.jorrery;
import java.awt.Color;
import java.awt.Graphics2D;
/**
 *
 * @author  Default
 * @version 
 */
public class GCirclePlanet extends GRoundPlanet {

    /** Creates new GShadedRoundPlanet */
    public GCirclePlanet(Planet planet) {
        super(planet);
    }
    public GCirclePlanet(Planet planet,Color c1,Color c2) {
        super(planet,c1,c2);
    }
    
    public GCirclePlanet() {
    }
    
    public void draw(Graphics2D g) {
        //move shape
        shape.x = planet.pos.x - size/2;
        shape.y = planet.pos.y - size/2;

        g.setColor(colour1);
        g.draw(shape);
    }   

}
