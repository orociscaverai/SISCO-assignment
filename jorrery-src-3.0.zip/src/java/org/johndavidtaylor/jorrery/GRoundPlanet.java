/*
 * GPlanet.java
 *
 * Created on 16 January 2001, 13:33
 */

package org.johndavidtaylor.jorrery;
import java.awt.Color;
import java.awt.Shape;
import java.awt.geom.Ellipse2D;
/**
 *  Planets tend to be round, so they're pretty much all going to extend this.
 * @author  JTAYLOR3
 */
public abstract class GRoundPlanet extends GAbstractPlanet  {
    protected Ellipse2D.Double shape;
    
    /** Creates new GPlanet */
    public GRoundPlanet(Planet planet) {
        this.planet = planet;
        planet.setGraphic(this);
    }
    public GRoundPlanet(Planet planet, Color c1, Color c2) {
        this(planet);
        setColour1(c1);setColour2(c2);
    }
    
    public GRoundPlanet() {
    }
    
    public Shape getShape() {
        return shape;
    }      

    public void setSize(double sz) {
        super.setSize(sz);
        shape = new Ellipse2D.Double(-size/2,-size/2,size,size);
    }
}
