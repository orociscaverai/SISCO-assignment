/*
 * Planet.java
 *
 * Created on 15 January 2001, 13:51
 */

package org.johndavidtaylor.jorrery;


/** This class is essentially just a struct for the physical data
 * describing a planet, its position, velocity and mass.  The
 * physical appearance of the planet is delegated to a {@link GPlanet }.
 *
 * @author JTAYLOR3
 */
public class Planet extends java.lang.Object {
    GPlanet graphic;
     
    /** The velocity of the planet.  Made public to allow direct access
     * for efficiency reasons....but not entirely comfortable with it.
     */    
    public TwoVec vel; 
/** The current position of the planet.
 */
    public TwoVec pos;
    /** The mass of the planet
     */    
    public double mass;
    String name="default";

    /** Construct a new planet with the given parameters.
     * @param pos
     * @param vel
     * @param mass
     * @param name
     */    
    public Planet(TwoVec pos, TwoVec vel, double mass, String name){
        this.pos=pos;
        this.vel=vel;
        this.mass=mass;
        this.name=name;
    }
    
    public Planet() {
        this(new TwoVec(), new TwoVec(), 1.0, "");
    }
    
    /** Return the planet's name.
     */    
    public String toString() {
        return name;
    }
    
    /** Getter for property name.
     * @return Value of property name.
 */
    public String getName() {
        return name;
    }
    
    /** Setter for property name.
     * @param name New value of property name.
 */
    public void setName(String name) {
        this.name = name;
    }
    
    /** Get the graphical representation of this planet.
     */    
    public GPlanet getGraphic() {
        return graphic;
    }
    /** Set the graphical representation of this planet - must be
     * set before the planet is used.
     */    
    public void setGraphic(GPlanet graphic) {
        this.graphic = graphic;
    }
    
    /** Getter for property mass.
     * @return Value of property mass.
 */
    public double getMass() {
        return mass;
    }
    
    /** Setter for property mass.
     * @param mass New value of property mass.
 */
    public void setMass(double mass) {
        this.mass = mass;
    }
    
}
