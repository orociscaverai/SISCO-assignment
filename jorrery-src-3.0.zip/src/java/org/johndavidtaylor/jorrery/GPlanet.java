/*
 * GPlanet.java
 *
 * Created on 16 January 2001, 13:43
 */

package org.johndavidtaylor.jorrery;
import java.awt.Color;
import java.awt.Graphics2D;
/** A number of different graphical representations of planets
 * are available and they all implement this interface.  Each
 * representation has two associated colours which are used e.g.
 * as fore and background colours for any text label referring to
 * the planet.  To make life easier for users to associated a
 * text label with a particular planet it would be a good idea
 * for the {@link draw(Graphics)} method to use these colours to
 * draw the planet.
 *
 * @author JTAYLOR3
 */
public interface GPlanet {
    //public Shape getShape() ;    
    

    /** Instructs the planet to draw itself onto this graphics context.
     * @param g the said graphics context
     */    
    public void draw( Graphics2D g);
    

    /** Getter for property colour1.
     * @return Value of property colour1.
 */
    public Color getColour1();
    

    /** Setter for property colour1.
     * @param colour1 New value of property colour1.
 */
    public void setColour1(Color colour1);
    

    /** Getter for property colour2.
     * @return Value of property colour2.
 */
    public Color getColour2();
    

    /** Setter for property colour2.
     * @param colour2 New value of property colour2.
 */
    public void setColour2(Color colour2);
    
    public void setPlanet(Planet p);
    
    public void setSize(double size);
    
    public double getSize();
    
}

