/*
 * Created on 30-May-2005
 *
 * @todo To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package org.johndavidtaylor.jorrery.utils;

import java.awt.Dimension;
import java.awt.Point;
import java.awt.Toolkit;

import javax.swing.JFrame;

/**
 *
 * Centers a given frame.  Surely there's a better way?
 * @author Jon Tayler johndavidtaylor@users.sourceforge.net
 * 
 */
public class FrameCenterer {

    private JFrame theFrame;

    /**
     * 
     */
    public FrameCenterer(JFrame theFrame) {
        this.theFrame = theFrame;
    }

    public void center() {
        center(0,0);
    }

    /**
     * Moves a frame to the centre, then offsets it
     * @param offsetX offset in the x direction
     * @param offsetY offset in the y direction
     */
    public void center(int offsetX, int offsetY) {
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        Dimension d = theFrame.getSize();
        int x = (screenSize.width - d.width) / 2 + offsetX;
        int y = (screenSize.height - d.height) / 2 + offsetY;
        Point pt = new Point(x, y);
        theFrame.setLocation(pt);
        
    }
}
