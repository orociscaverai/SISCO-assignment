/*
 * PointBuffer.java
 *
 * Created on 26 November 2001, 17:24
 */

package org.johndavidtaylor.jorrery.utils;

/**
 * Stores pairs of points up to a certain maximum.  Doesn't guarantee any ordering
 * @author  JTAYLOR3
 * @version 1.0
 */
public class PointBuffer {
    private int _max;
    private double[] _x;
    private double[] _y;
    private int _number = 0;
    private int _next = 0;
    /** Creates new PointBuffer */
    public PointBuffer(int max) {
        _max = max;
        _x = new double[max];
        _y = new double[max];
    }
    
    public double getX(int index) {
        return _x[(_next+index)%_number];
    }
    
    public double getY(int index) {
        return _y[(_next+index)%_number];
    }
    
    public int getNumberStored() {
        return _number;
    }
    
    public void push(double x, double y) {
        _x[_next] = x;
        _y[_next] = y;
        ++_next;
        _next%=_max;
        _number++;
        _number=Math.min(_number, _max);
    }
}
