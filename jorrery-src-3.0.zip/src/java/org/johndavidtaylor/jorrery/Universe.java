/*
 * Universe.java
 *
 * Created on 15 January 2001, 13:50
 */

package org.johndavidtaylor.jorrery;
import java.util.List;
//import com.johndavid_taylor.beans.choice.*;
/** This class provides the space for the {@link Algorithm } to sit in.
 * It keeps track of time and tells the Algorithm when to do
 * its next step.  It basically provides the interface to the
 * outside world to the numerical algorithm and the planets etc.
 *
 *
 * Doesn't have a lot to do
 *
 * @author JTAYLOR3
 */
public class Universe extends Object {
    private double size = 100;
    private List arrayOfPlanets;
    private Algorithm algorithm;
    
   
    /** Returns a "size" for the universe which is used by some Views
     * to determine the area to show initially.
     */

    public double getSize() {
        return size;
    }
    
    /** Adopts the collection of planets.
     */    
    public void setArrayOfPlanets(List planets) {
        arrayOfPlanets = planets;
    }
    
    public void setSize(double size) {
        this.size = size;
    }
    
    
    /** Returns a reference to the vector of planets.
     */    
    public List getVectorOfPlanets(){
        return arrayOfPlanets;
    }

    /** Get the current elapsed universe time.
     */    
    public double getTime() {
        return time;
    }
    
    private double time = 0;
    
    public Universe(Algorithm algorithm, List arrayOfPlanets, double size) {
        this.arrayOfPlanets = arrayOfPlanets;
        this.algorithm = algorithm;
        this.size = size;
    }
    
    /** Causes the algorithm to execute its next step and updates
     * universe time by dt.
     * @param dt
     */    
    public void tick(double dt) {
        algorithm.tick(dt);
        time+=dt;
    }
    
    
    /** Getter for property algorithm.
     * @return Value of property algorithm.
 */
    public Algorithm getAlgorithm() {
        return algorithm;//.toString();
    }
    
    /** Setter for property algorithm.
     * @param algorithm New value of property algorithm.
 */
    public void setAlgorithm(Algorithm algorithm) {
        this.algorithm = algorithm;
    }

    
}
