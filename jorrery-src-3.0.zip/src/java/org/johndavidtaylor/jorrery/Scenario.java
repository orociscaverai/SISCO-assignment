/*
 * Scenario.java
 *
 * Created on 10 July 2001, 22:16
 */

package org.johndavidtaylor.jorrery;

/** Scenarios are responsible for setting the initial conditions
 * for the planets, giving an indication of the size of the
 * universe, typical planet masses, velocities (so that new
 * planets can be added with random, but sensible properties), and
 * also for determining which algorithm is to be used.  New Scenarios
 * should be put in the {@link com.johndavid_taylor.nbody.scenarios } package.
 *
 *
 * @author JDT
 * @todo The relationship between scenarios, algorithms,
 * initial conditions etc needs to be sorted out -
 * at the moment it's not very well thought out.
 */
public interface Scenario {
    

    public Algorithm getAlgorithm();
    

    public java.util.List getPlanets();
    

    public double getUniverseMaxX();
    
    /** Return a suitable delta t in seconds */
    public double getTimeStep();
    
    public double getTypicalPlanetMass(); //usually in kg
    public double getTypicalPlanetVelocity(); //usually in m/s
    public double getTypicalPlanetDiameter();// in same units as Universe max x
    
}

