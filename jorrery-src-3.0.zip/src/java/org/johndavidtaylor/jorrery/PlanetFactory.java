/*
 * PlanetFactory.java
 *
 * Created on 21 January 2001, 12:21
 */

package org.johndavidtaylor.jorrery;
import java.awt.Color;

/** This class has the responsibility of creating suitable new
 * random planets.  It's crap and needs rewriting.
 *
 * @author JDT
 */
public class PlanetFactory extends Object {

    static private String [] names = { 
        "Vogon",
        "Bethselamim",
        "Tatooine",
        "Gallifrey",
        "Ork",
        "Golgafrincham",
        "Vulcan"};
        
        /** Holds value of property randomColours. */
        static  boolean randomColours = true;
        
        /** Getter for property randomColours.
         * @return Value of property randomColours.
 */
        public boolean isRandomColours() {
            return randomColours;
        }
        
        /** Setter for property randomColours.
         * @param randomColours New value of property randomColours.
 */
        public void setRandomColours(boolean randomColours) {
            PlanetFactory.randomColours = randomColours;
        }
        
  
    static private int nindex=0;
    
    static private Color colour1 = Color.red;
    static private Color colour2 = Color.black;
    
    /** Holds value of property randomPlanetType. */
    static private boolean randomPlanetType = true;
    
    /** Holds value of property randomMass. */
    static private boolean randomMass = true;
    
    /** Holds value of property maximumVelocity. */
    static private double newPlanetMaximumVelocity = 0.0;
    
    /** Holds value of property newPlanetType. */
    static private GRoundPlanet newPlanetType;
    
    /** Holds value of property newPlanetMass. */
    static private double newPlanetMass = 5.0;
    
    /** Holds value of property newPlanetMaxDistance. */
    static private double newPlanetMaxDistance = 1.0;
    
    /** Holds value of property newPlanetDiameter. */
    static private double newPlanetDiameter = 100;;
    
    static private String getNextName() {
        if (nindex<names.length) {
            return names[nindex++];
        }
        else {
            return "Planet " + nindex++;
        }
    }
         
    static public Planet getRandom(){

        TwoVec pos = new TwoVec(1- 2 *Math.random(),1- 2 *Math.random());
        TwoVec vel = new TwoVec(1.0-2*Math.random(),1-2*Math.random());
        pos = pos.times(newPlanetMaxDistance);
        vel = vel.times(newPlanetMaximumVelocity);//OK so it's not strictly correct

        double mass = randomMass? newPlanetMass*Math.random() : newPlanetMass;

        Planet p = new Planet(pos,vel,mass,"");        
        
        String name = getNextName();
        p.setName(name);
        
        Color c1,c2;
        if (randomColours) {
            c1 = new Color((float)Math.random(),(float)Math.random(),(float)Math.random());
            c2 = new Color((float)Math.random(),(float)Math.random(),(float)Math.random());
        }
        else {
            c1 = colour1;
            c2 = colour2;
        }
        
        GRoundPlanet gp;
        if (randomPlanetType) {
            final int N_PLANET_TYPES = 4;
            int choice = (int) (Math.random() * N_PLANET_TYPES);
            switch (choice) {
                case 0:
                    gp = new GCirclePlanet(p,c1,c2);
                    break;
                case 1:
                    gp = new GBandedRoundPlanet(p,c1,c2);
                    break;
                case 2:
                    gp = new GPlainPlanet(p,c1,c2);
                    break;
                default:
                    gp = new GShadedRoundPlanet(p,c1,c2);
                    break;

            }
        }
        else
        {
            gp = new GBandedRoundPlanet(p,c1,c2);
        }
        double diam = newPlanetDiameter*mass/newPlanetMass;
        gp.setSize(diam);
        p.setGraphic(gp);
        return p;
    }
    
    /** Getter for property colour1.
     * @return Value of property colour1.
 */
    public Color getColour1() {
        return colour1;
    }
    
    /** Setter for property colour1.
     * @param colour1 New value of property colour1.
 */
    public void setColour1(Color c1) {
        colour1=c1;
    }
    
    /** Getter for property colour2.
     * @return Value of property colour2.
 */
    public Color getColour2() {
        return colour2;
    }
    
    /** Setter for property colour2.
     * @param colour2 New value of property colour2.
 */
    public void setColour2(Color c2) {
        colour2 = c2;
    }
    
    /** Getter for property randomPlanetType.
     * @return Value of property randomPlanetType.
 */
    public boolean isRandomPlanetType() {
        return randomPlanetType;
    }
    
    /** Setter for property randomPlanetType.
     * @param randomPlanetType New value of property randomPlanetType.
 */
    public void setRandomPlanetType(boolean randomPlanetType1) {
        randomPlanetType = randomPlanetType1;
    }
    
    /** Getter for property randomMass.
     * @return Value of property randomMass.
 */
    public boolean isRandomMass() {
        return randomMass;
    }
    
    /** Setter for property randomMass.
     * @param randomMass New value of property randomMass.
 */
    public void setRandomMass(boolean r) {
        randomMass = r;
    }
    
    /** Getter for property maximumVelocity.
     * @return Value of property maximumVelocity.
 */
    public double getNewPlanetMaximumVelocity() {
        return newPlanetMaximumVelocity;
    }
    
    /** Setter for property maximumVelocity.
     * @param maximumVelocity New value of property maximumVelocity.
 */
    public void setNewPlanetMaximumVelocity(double maximumVelocity) {
        newPlanetMaximumVelocity = maximumVelocity;
    }
    
    /** Getter for property newPlanetType.
     * @return Value of property newPlanetType.
 */
    public GRoundPlanet getNewPlanetType() {
        return newPlanetType;
    }
    
    /** Setter for property newPlanetType.
     * @param newPlanetType New value of property newPlanetType.
 */
    public void setNewPlanetType(GRoundPlanet n) {
        newPlanetType = n;
    }
    
    /** Getter for property newPlanetMass.
     * @return Value of property newPlanetMass.
 */
    public double getNewPlanetMass() {
        return newPlanetMass;
    }
    
    /** Setter for property newPlanetMass.
     * @param newPlanetMass New value of property newPlanetMass.
 */
    public void setNewPlanetMass(double n) {
        newPlanetMass = n;
    }
    
    /** Getter for property newPlanetMaxDistance.
     * @return Value of property newPlanetMaxDistance.
     */
    public double getNewPlanetMaxDistance() {
        return newPlanetMaxDistance;
    }
    
    /** Setter for property newPlanetMaxDistance.
     * @param newPlanetMaxDistance New value of property newPlanetMaxDistance.
     */
    public void setNewPlanetMaxDistance(double newPlanetMaxDistance) {
        PlanetFactory.newPlanetMaxDistance = newPlanetMaxDistance;
    }
    
    /** Getter for property newPlanetDiameter.
     * @return Value of property newPlanetDiameter.
     */
    public double getNewPlanetDiameter() {
        return newPlanetDiameter;
    }
    
    /** Setter for property newPlanetDiameter.
     * @param newPlanetDiameter New value of property newPlanetDiameter.
     */
    public void setNewPlanetDiameter(double newPlanetDiameter) {
        PlanetFactory.newPlanetDiameter = newPlanetDiameter;
    }
    
}
