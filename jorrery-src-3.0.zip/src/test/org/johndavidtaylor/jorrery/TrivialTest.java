/* $Id: TrivialTest.java,v 1.1 2003/10/23 11:29:35 johndavidtaylor Exp $
 * Created on 23-Oct-2003 by John Taylor jdt@roe.ac.uk .
 * 
 */
package org.johndavidtaylor.jorrery;

import junit.framework.TestCase;

/**
 * @author jdt
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class TrivialTest extends TestCase {

  /**
   * Constructor for TrivialTest.
   * @param arg0
   */
  public TrivialTest(String arg0) {
    super(arg0);
  }

  public static void main(String[] args) {
    junit.textui.TestRunner.run(TrivialTest.class);
  }

}

/*
*$Log: TrivialTest.java,v $
*Revision 1.1  2003/10/23 11:29:35  johndavidtaylor
*Initial commit
*
*/